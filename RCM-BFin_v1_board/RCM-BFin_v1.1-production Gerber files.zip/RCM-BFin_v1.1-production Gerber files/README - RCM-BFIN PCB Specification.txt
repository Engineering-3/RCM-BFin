RCM-BFIN PCB Specification
-------------------------------

BOARD STACK:

Layers:
1. Copper Top
2.
3.
4.
5.
6. Copper Bottom

SILKSCREENS:

1. Layers 1 and 6

PASTE MASKS:

1. Layer 1

BOARD MATERIALS:

RoHS Compliant: YES
Copper: 1oz
Finish: Immersion Gold
Material: FR-406
Thickness: 62 mil
Tg>170
Soldermask: SMOBC BLUE
Silkscreen: White

BOARD TESTING:

Electrical Test: YES
